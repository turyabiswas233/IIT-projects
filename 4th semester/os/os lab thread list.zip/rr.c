#include <stdio.h>
#include <stdlib.h>

typedef struct Task
{
    char *taskName;
    int priority;
    int cpuBurst;
    int startTime;
    int finishTime;
} Task;
void printTask(Task t)
{
    printf("%s\t: %02d ms %02d ms {%02d | %02d}\n", t.taskName, t.startTime, t.finishTime, t.priority, t.cpuBurst);
}
int isCompletedTasks(Task *tasks, int n)
{
    int flag = 0;
    for (size_t i = 0; i < n; i++)
    {
        if (tasks[i].cpuBurst != 0)
        {
            flag = 1;
            break;
        }
    }
    return flag;
}
int main(int argc, char const *argv[])
{
    int n;
    scanf(" %d", &n);
    int chunk = 100000000;
    Task *tasks = (Task *)malloc(sizeof(Task) * n);
    for (size_t i = 0; i < n; i++)
    {
        Task n = *(Task *)malloc(sizeof(Task));

        n.taskName = (char *)malloc(sizeof(char) * 10);
        scanf(" %s %d %d", n.taskName, &n.priority, &n.cpuBurst);
        n.startTime = n.finishTime = 0;
        tasks[i] = n;
        chunk = (chunk > n.cpuBurst ? n.cpuBurst : chunk);
    }
    chunk = (chunk / 2 > 0 ? chunk / 2 + 1 : 1);
    int totalTime = 0, avgWT = 0;
    Task *tempTask = tasks;
    int currentTid = -1;
    Task *preTask = NULL;
    // do
    // {
    //     int dif = tempTask[currentTid].cpuBurst - chunk;
    //     currentTid = (currentTid + 1) % n;
    //     if (tempTask[currentTid].cpuBurst == 0)
    //         continue;
    //     if (dif <= 0)
    //         tempTask[currentTid].cpuBurst = 0;
    //     else
    //         tempTask[currentTid].cpuBurst -= chunk;
    //     if (preTask == NULL)
    //     {
    //         preTask = &tempTask[currentTid];
    //         continue;
    //     }
    //     else
    //     {
    //         if (tempTask[currentTid].startTime == 0)
    //             tempTask[currentTid].startTime = preTask->finishTime;
    //         tempTask[currentTid].finishTime = chunk;
    //     }

    // } while (isCompletedTasks(tempTask, n) == 0);

    // for (size_t i = 0; i < n; i++)
    // {
    //     tasks[i].startTime = tempTask[i].startTime;
    //     tasks[i].finishTime = tempTask[i].finishTime;
    // }

    for (size_t i = 0; i < n; i++)
    {
        printTask(tasks[i]);
    }
    printf("Average wating time: %0d ms\n", avgWT / n);
    printf("CHUNK SIZE[rr]: %0d ms\n", chunk);

    return 0;
}
