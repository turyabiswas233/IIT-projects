public class HumiditySensorAdapter implements Sensor {
    private HumiditySensorLegacy humidityLegacy;

    HumiditySensorAdapter(HumiditySensorLegacy humidityLegacy) {
        this.humidityLegacy = humidityLegacy;
    }

    @Override
    public String getData() {
       return  humidityLegacy.getHumidityLevel();
    }
}
