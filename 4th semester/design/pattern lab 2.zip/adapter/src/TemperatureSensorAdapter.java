public class TemperatureSensorAdapter implements Sensor {
    private TemperatureSensorLegacy tempLegacy;

    TemperatureSensorAdapter(TemperatureSensorLegacy tempLegacy) {
        this.tempLegacy = tempLegacy;
    }

    @Override
    public String getData() {
        return tempLegacy.readTemp();
    }

}
