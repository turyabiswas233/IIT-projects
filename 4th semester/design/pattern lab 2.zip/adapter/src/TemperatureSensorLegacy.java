public class TemperatureSensorLegacy {
    public String readTemp() {
        return "Temperature Sensor: 23deg C";
    }

}
