public class App {
    public static void main(String[] args) throws Exception {
        Sensor hsa = new HumiditySensorAdapter(new HumiditySensorLegacy());
        Sensor tsa = new TemperatureSensorAdapter(new TemperatureSensorLegacy());

        System.out.println(tsa.getData());
        System.out.println(hsa.getData());
    }
}
