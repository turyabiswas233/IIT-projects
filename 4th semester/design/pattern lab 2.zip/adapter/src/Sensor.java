public interface Sensor {
    public String getData();
}
