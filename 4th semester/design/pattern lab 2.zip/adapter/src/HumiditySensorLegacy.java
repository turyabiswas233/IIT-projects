public class HumiditySensorLegacy {
    public String getHumidityLevel() {
        return "Humidity sensor: 50%";
    }

}
