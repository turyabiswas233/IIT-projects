enum ROLE {
    ADMIN, GUEST
}