public class DatabaseProxy implements Database {
    protected RealDatabase realDatabase;
    protected User user;

    public DatabaseProxy(ROLE role) {
        user = new User(role);
        realDatabase = new RealDatabase();
    }

    @Override
    public void query(String sql) {
        if (allowQueryUsers(user))
            System.out.print("ADMIN: ");
        if (allowQueryUsers(user))
            realDatabase.query(sql);
        else
            System.out.println("GUEST: Access denied for query: " + sql);
    }

    protected boolean allowQueryUsers(User user) {
        return (user.getRole() == ROLE.ADMIN);
    }
}
