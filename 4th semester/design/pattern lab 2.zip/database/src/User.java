
public class User {
    private ROLE role;

    public User(ROLE role) {
        this.role = role;
    }

    public ROLE getRole() {
        return role;
    }

}
