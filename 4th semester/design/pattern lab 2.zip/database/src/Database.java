public interface Database {
    public void query(String sql);
}