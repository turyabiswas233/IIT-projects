public class RealDatabase implements Database {

    @Override
    public void query(String sql) {
        // TODO Auto-generated method stub
        System.out.println("Executing query: " + sql);
    }

}
