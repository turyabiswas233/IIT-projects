public class App {
    public static void main(String[] args) throws Exception {
        Database admin = new DatabaseProxy(ROLE.ADMIN);
        Database guest = new DatabaseProxy(ROLE.GUEST);

        admin.query("SELECT * FROM users");
        guest.query("SELECT * FROM users");

    }
}
