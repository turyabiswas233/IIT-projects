public class FormattedCharacter {
    private char character;
    private TextFormat textFormat;

    public FormattedCharacter(char character, TextFormat textFormat) {
        this.character = character;
        this.textFormat = textFormat;
    }

    @Override
    public String toString() {
        return "Char: " + character + " | Format: " + textFormat;
    }
}
