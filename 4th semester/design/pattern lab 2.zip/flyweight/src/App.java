public class App {
    public static void main(String[] args) throws Exception {
        TextFormat format1 = new TextFormat("Arial", 12, "Bold");
        TextFormat format2 = new TextFormat("Times", 12, "Italic");

        FormattedCharacter h, e, l1, l2, u;
        h = new FormattedCharacter('H', format1);
        e = new FormattedCharacter('e', format1);
        l1 = new FormattedCharacter('l', format1);
        l2 = new FormattedCharacter('l', format2);
        u = new FormattedCharacter('u', format2);

        TextFormatFactory tff = new TextFormatFactory(h,e,l1,l2,u);
        tff.printString();

    }
}

// factory.get('Arial', 2, 'bold');
