import java.util.ArrayList;

public class TextFormatFactory {
    ArrayList<TextFormat> format = new ArrayList<>();
    ArrayList<FormattedCharacter> string = new ArrayList<>();

    public TextFormatFactory(FormattedCharacter... characters) {
        for (FormattedCharacter formattedCharacter : characters) {
            this.string.add(formattedCharacter);
        }
    }

    public void printString() {
        for (FormattedCharacter formattedCharacter : string) {
            System.out.println(formattedCharacter);
        }
    }
}
