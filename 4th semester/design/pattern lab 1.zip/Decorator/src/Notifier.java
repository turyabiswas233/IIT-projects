public class Notifier {
    void send(String message) {
        System.out.println("Message: "+message);
    }
}
