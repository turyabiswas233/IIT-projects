public class App {
    public static void main(String[] args) throws Exception {
        Application app = new Application();

        Notifier stack = new Notifier();
        
        boolean facebookEnabled = true;
        boolean slackEnabled = true;
        boolean smsEnabled = true;

        if(facebookEnabled) {
            stack = new FacebookDecorator(stack);
        }
        if(slackEnabled){
            stack = new SlackDecorator(stack);
        }
        if(smsEnabled){
            stack = new SMSDecorator(stack);
        }



        app.setNotifier(stack);
        app.doSomething();

    }
}
