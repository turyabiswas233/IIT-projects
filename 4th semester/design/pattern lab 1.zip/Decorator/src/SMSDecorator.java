public class SMSDecorator extends BaseDecorator {
    Notifier notifier;

    public SMSDecorator(Notifier wrappee) {
        super(wrappee);
        this.notifier = wrappee;
    }

    @Override
    public void send(String message) {
        super.send(message+"[sms]"); 
    }
}
