public class FacebookDecorator extends BaseDecorator{
    Notifier notifier;
    public FacebookDecorator(Notifier wrappee){
        super(wrappee);
        this.notifier = wrappee;
    }
    
    @Override
    public void send(String message) { 
        super.send(message+"[facebook]");
    }    
}
