public interface CourseComponent {
    String getName();
    double computeDuration();
}
