public class App {
    public static void main(String[] args) throws Exception {
        CourseComponent p = new Project("P1", 3);
        CourseComponent l = new Lesson("L1", 1);
        CourseComponent q = new Quiz("Q1", 2);

        Course c = new Course("SE");
        c.addComponent(p);
        c.addComponent(l);
        c.addComponent(q);

        c.computeDuration();
    }
}
