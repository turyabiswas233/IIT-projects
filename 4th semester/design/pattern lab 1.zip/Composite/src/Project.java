public class Project implements  CourseComponent {
    private String name;
    private double duration;

    public Project(String name, double duration) {
        this.name = name;
        this.duration = duration;
    }

    @Override
    public String getName(){
        return name;
    }

    @Override 
    public double computeDuration(){
        System.out.println(" - Project:" + name + "Duration: "+ duration+" hours");
        return duration;
    }
    
}
