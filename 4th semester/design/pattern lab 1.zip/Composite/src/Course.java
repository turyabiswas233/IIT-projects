import java.util.ArrayList;
import java.util.List;

// Course.java
public class Course implements CourseComponent {
    private String name;
    private List<CourseComponent> components = new ArrayList<>();

    public Course(String name) {
        this.name = name;
    }

    public void addComponent(CourseComponent component) {
        components.add(component);
    }

    public void removeComponent(CourseComponent component) {
        components.remove(component);
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public double computeDuration() {
        double totalDuration = 0;
        System.out.println("Calculating duration for Course: " + name);
        for (CourseComponent component : components) {
            totalDuration += component.computeDuration();
        }
        System.out.println("Total duration for Course '" + name + "': " + totalDuration + " hours");
        return totalDuration;
    }
}