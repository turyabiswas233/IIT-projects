public class Lesson implements CourseComponent{
     private String name;
    private double duration;

    public Lesson(String name, double duration) 
    {
        this.name = name;
        this.duration = duration;
    }

    @Override 
    public String getName(){
        return name;
    }

    @Override 
    public double computeDuration(){
        System.out.println(" - Lesson: "+ name +" duration: "+duration+ " hours");
        return duration;
    }
}
