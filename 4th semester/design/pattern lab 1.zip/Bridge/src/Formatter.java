public interface Formatter {
    String fromat(String header, String content) ;
}