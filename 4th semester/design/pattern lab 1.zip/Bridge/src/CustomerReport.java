public class CustomerReport extends Report{
    private String customerInfo;

    public CustomerReport (Formatter formatter, String customerInfo) {
        super(formatter);
        this.customerInfo = customerInfo;
    }

    @Override
    public String generate() {
        String header = "Customer Feedback Report";
        return formatter.fromat(header, customerInfo);
    }
}