public class App {
    public static void main(String[] args) throws Exception {
        Formatter csvFormatter = new CSVFormatter();
        Formatter pdfFormatter = new PDFFormatter();


        Report salesReport = new SalesReport(csvFormatter, "Salesman selling report page");

        Report customerReport = new CustomerReport(pdfFormatter, "Customer report page in pdf");

        System.out.println(salesReport.generate());
        System.out.println(customerReport.generate());
        salesReport.setFormatter(pdfFormatter);
        System.out.println(salesReport.generate());
    }
}
