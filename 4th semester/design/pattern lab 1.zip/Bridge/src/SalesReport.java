public class SalesReport extends Report {
    private String salesData;

    public SalesReport(Formatter formatter, String salesData) {
        super(formatter);

        this.salesData = salesData;
    }

    @Override
    public String generate() {
        String header = "Monthly sales Report";
        return formatter.fromat(header, salesData);
    }
}
