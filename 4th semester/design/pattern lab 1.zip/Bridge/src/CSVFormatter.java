public class CSVFormatter implements Formatter {
    @Override
    public String fromat(String header, String content) {
        return "CSV Report:" + "\nHeader:" + header + "\nContent: " + content;
    }
}