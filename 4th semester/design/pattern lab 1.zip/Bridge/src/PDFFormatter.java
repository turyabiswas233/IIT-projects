public class PDFFormatter implements Formatter {
    @Override
    public String fromat(String header, String content) {
        return "PDF Report:" + "\nHeader:" + header + "\nContent: " + content;
    }
}
