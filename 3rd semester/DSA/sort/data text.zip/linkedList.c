#include <stdio.h>
#include <stdlib.h>

typedef struct node
{
    int data;
    struct node *next;
} node;

typedef struct tree
{
    node *N;
    struct tree *left;
    struct tree *right;
} tree;
node *createNode(int data)
{
    node *newnode = (node *)malloc(sizeof(node));
    newnode->data = data;
    newnode->next = NULL;
    return newnode;
}
tree *createBst(tree *root, node *head, int *counter)
{
    if (root == NULL)
    {
        tree *r = (tree *)malloc(sizeof(tree));
        r->N = head;
        r->left = r->right = NULL;
        *counter = *counter + 1;
        return r;
    }
    else if (root->N->data > head->data)
    {
        root->left = createBst(root->left, head, counter);
    }
    else if (root->N->data < head->data)
    {
        root->right = createBst(root->right, head, counter);
    }
    return root;
}
unsigned int count=0;
void inorder(tree *root)
{
    if (root == NULL)
        return;
    inorder(root->left);
    printf("| 0x%x ", root->N->data);
    count++;
    if(count%3==0) printf("|\n");
    inorder(root->right);
}
int main(int argc, char const *argv[])
{
    node *head = NULL;
    node *temp;
    int n, x, *ac_data;
    scanf("%d", &n);
    if (n == 0)
        return 1;
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &x);
        if (i == 0)
        {
            temp = createNode(x);
            head = temp;
        }
        else
        {
            temp->next = createNode(x);
            temp = temp->next;
        }
    }

    tree *root = NULL;
    temp = head;
    *ac_data = 0;
    while (temp)
    {
        root = createBst(root, temp, ac_data);
        temp = temp->next;
    }
    printf("#TOTAL DATA: %d\n#ACCEPTED DATA: %d\n#SKIPPED DATA: %d\n", n, *ac_data, n - *ac_data);
    inorder(root);

    printf("\n");

    return 0;
}
